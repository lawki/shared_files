import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import {ServerNameService} from '../services/server-name.service'
@Injectable()
export class GetTokenService {
  accessTokenUrl:string = "authentication/callback";  
  constructor(private http:Http,private serverName:ServerNameService) { }
  getToken(info){
      console.log(info);
    return this.http.post(this.serverName.getURL()+this.accessTokenUrl,
      {
        code:info
    });
  }

}
