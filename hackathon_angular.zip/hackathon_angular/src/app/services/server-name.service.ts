import { Injectable } from '@angular/core';

@Injectable()
export class ServerNameService {
   url:String = "http://localhost:8080/"; //
  constructor() {
    
   }
   getURL(){
     return this.url;
   }
}
