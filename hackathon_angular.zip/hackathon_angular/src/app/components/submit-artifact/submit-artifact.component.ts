import { Component, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { ActivatedRoute, Params,Router } from "@angular/router";
import {ServerNameService} from '../../services/server-name.service';
@Component({
  selector: 'app-submit-artifact',
  templateUrl: './submit-artifact.component.html',
  styleUrls: ['./submit-artifact.component.css']
})
export class SubmitArtifactComponent implements OnInit {
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private serverName:ServerNameService,
    ) {
       
    }
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;
  _id: any;
  myurl: any='authentication/upload/';
 
  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }
 
  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }
  
  public uploader:FileUploader = null;
  
  

  ngOnInit() {
    this.myurl = this.serverName.getURL()+ this.myurl;
    this.uploader = new FileUploader({url: this.myurl });
    console.log("updated URL: ");
    console.log(this.myurl);
    this.route.params.forEach((params: Params) => {
      this._id = params['_id'];
    });
    this.uploader.onBuildItemForm = (fileItem: any, form: any) => {
      form.append('_id' , this._id);
      form.append('username', JSON.parse(localStorage.getItem('user')).username);
     };
     this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
      console.log("ImageUpload:uploaded:", item, status);
      this.router.navigate(['/profile']);
  };
  }

}
