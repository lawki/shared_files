import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {Router,ActivatedRoute, Params,UrlTree} from '@angular/router';
import {Http} from '@angular/http';
import {GetTokenService} from '../../services/get-token.service';
import { AuthService } from '../../services/auth.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  username = null;
  email = null;
  constructor(
  ) { }

  ngOnInit() {
      let info = JSON.parse(localStorage.getItem('user'));
      this.username = info?info.username:'Not found';
      this.email = info?info.email:'Not found';
    }
    
    }